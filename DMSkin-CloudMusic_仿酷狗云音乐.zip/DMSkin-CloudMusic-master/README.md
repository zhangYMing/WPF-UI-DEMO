# DMSkin-CloudMusic
网易云音乐-用WPF来做网易云音乐客户端会怎么样?
## 【网易云音乐】

## 下载体验包
[下载地址](https://github.com/944095635/DMSkin-CloudMusic/releases)

## 编译、修改、学习
````csharp
源码引用了 DMSkin-for-WPF 
如果你需要自行编译、修改、学习等，请同时下载DMSKIN.WPF
https://github.com/944095635/DMSkin-for-WPF
````

此项目持续更新中..

<Image src='https://raw.githubusercontent.com/944095635/DMSkin-CloudMusic/master/Screenshot/demo1002.png'></Image>

<Image src='https://raw.githubusercontent.com/944095635/DMSkin-CloudMusic/master/Screenshot/demo1001.png'></Image>

## 【更新日志】

### 1.0.0.2 (2018-11-5)
1. 本地音乐和云盘都可以使用。
2. 云盘播放音乐下载逻辑等待优化。
3. 本地搜索&缓存音乐等待优化。
3. 音频解码器等待优化。

### 1.0.0.1 (2018-11-5)
1. Frame导航完善。
2. 本地音乐界面初步完善。

### 1.0.0.0 (2018-11-5)
1. 项目结构搭建完成。
2. 主界面初步完成。

